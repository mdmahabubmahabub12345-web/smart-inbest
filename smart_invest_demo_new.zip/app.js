function showMessage(msg){const t=document.getElementById('toast');t.textContent=msg;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),1800)}
function selectPlan(name){document.getElementById('activity').innerHTML='<div class="empty">Selected: <b>'+name+'</b> (demo only)</div>';showMessage(name+' plan selected')}
