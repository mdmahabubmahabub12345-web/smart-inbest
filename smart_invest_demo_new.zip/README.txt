SMART INVEST — UI DEMO

এটি একটি front-end demo মাত্র।
কোনো বাস্তব টাকা গ্রহণ, পাঠানো, investment বা payment করা হয় না।

Files:
- index.html
- style.css
- app.js

GitHub Pages-এ চালাতে তিনটি ফাইল repository root-এ upload করুন।
